<?php
// phpMyAdmin fixture entry point
